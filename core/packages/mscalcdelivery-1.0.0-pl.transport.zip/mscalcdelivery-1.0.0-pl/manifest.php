<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for msCalcDelivery.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5be27c6b371c905c7961493ee611ee87',
      'native_key' => 'mscalcdelivery',
      'filename' => 'modNamespace/43485df75184cb70d10ff7ae8fa3b02d.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3651de31363da86c4b035096bc688f1b',
      'native_key' => NULL,
      'filename' => 'modCategory/11e5ec8262584c2bfb902c7b62a46a13.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
  ),
);