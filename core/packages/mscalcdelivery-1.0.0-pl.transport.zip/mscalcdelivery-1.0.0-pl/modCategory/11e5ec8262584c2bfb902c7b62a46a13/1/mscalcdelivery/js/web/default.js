class msCalcDelivery{
    config = {
        action_url:"/assets/components/mscalcdelivery/action.php",
        selectors:{
            delivery_items:`[data-msCalcDelivery-items]`,
            required_field:`[data-msCalcDelivery-field]:not([disabled])`
        }
    }
    constructor(config) {
        this.config = {...this.config,config};
        let self = this;
        window.miniShop2.addCallback("Order.add.response.success","msCalcDelivery",(response)=>{
            console.log(response)
            if(response.data.city){
                console.log(response)
                self.fetch(self.config.action_url).then(response=>{
                    console.log(response)
                });
            }
        })
    }

    fetch(url, params = {}, method = "POST", headers = {'X-Requested-With': 'XMLHttpRequest'}) {
        let options = {method, headers};
        if (method === 'GET') {
            url = url + "?" + (new URLSearchParams(params).toString());
        } else {
            options.body = JSON.stringify(params);
        }
        return fetch(url, options);
    }
}