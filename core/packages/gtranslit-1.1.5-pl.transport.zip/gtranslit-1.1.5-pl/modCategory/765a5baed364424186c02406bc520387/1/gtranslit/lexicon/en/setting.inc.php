<?php

$_lang['setting_gtranslit.disable_cache'] = 'gtranslit.disable_cache';
$_lang['setting_gtranslit.lang.from'] = 'gtranslit.lang.from';
$_lang['setting_gtranslit.lang.to'] = 'gtranslit.lang.to';