gTranslit
--------------------
обновленные настройки
--------------------------------------------------------------------------------
friendly_alias_translit_class = "modx.gtranslit.modTransliterate"

friendly_alias_translit_class_path = "{core_path}components/gtranslit/model/"

friendly_alias_translit = "ru"

--------------------------------------------------------------------------------