<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '55198816ff1c119cb89267eb416c93cb',
      'native_key' => 'gtranslit',
      'filename' => 'modNamespace/7c68770b5620e6aa0376563ccc2d2751.vehicle',
      'namespace' => 'gtranslit',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c8ee1f9831459558b69543e36f94f63',
      'native_key' => 'gtranslit.disable_cache',
      'filename' => 'modSystemSetting/2b972f92237b50727bfbb98cd0ef0edf.vehicle',
      'namespace' => 'gtranslit',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3715c27f01cd7e24c394d4a69bfbfcd',
      'native_key' => 'gtranslit.lang.from',
      'filename' => 'modSystemSetting/44e5bf53257f4a458bdf74f16ac0d6b5.vehicle',
      'namespace' => 'gtranslit',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28e8d5902f07a55cd8fbd77e2a2f946b',
      'native_key' => 'gtranslit.lang.to',
      'filename' => 'modSystemSetting/491f319f7a59a7e5597a9643f07b2ca9.vehicle',
      'namespace' => 'gtranslit',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c186e5343272aa06dcc0a3f81b686b4',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/4ddc95d1570188b52dd214e80b1323b6.vehicle',
      'namespace' => 'gtranslit',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbeef14a572cbcaab38511f517993f50',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/d7ab64cf2b72d1fde2e1b88acb506c21.vehicle',
      'namespace' => 'gtranslit',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4f94ee737a25dc73af94bdc089dc9431',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/d15c240a0fd6cd2de69d4e06419b5f25.vehicle',
      'namespace' => 'gtranslit',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9d1f73cd58fc2f222a3d084539606d98',
      'native_key' => NULL,
      'filename' => 'modCategory/765a5baed364424186c02406bc520387.vehicle',
      'namespace' => 'gtranslit',
    ),
  ),
);