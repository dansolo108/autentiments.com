<?php
/**
 * Russian permissions Lexicon Entries for modMaxma
 *
 * @package modMaxma
 * @subpackage lexicon
 */
$_lang['modmaxma_save'] = 'Permission for save/update data.';