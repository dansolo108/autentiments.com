<?php
require_once (dirname(__DIR__) . '/maxmauser.class.php');
class maxmaUser_mysql extends maxmaUser {}