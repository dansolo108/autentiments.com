<?php
/**
 * English permissions Lexicon Entries for modMaxma
 *
 * @package modMaxma
 * @subpackage lexicon
 */
$_lang['modmaxma_save'] = 'Разрешает создание/изменение данных.';