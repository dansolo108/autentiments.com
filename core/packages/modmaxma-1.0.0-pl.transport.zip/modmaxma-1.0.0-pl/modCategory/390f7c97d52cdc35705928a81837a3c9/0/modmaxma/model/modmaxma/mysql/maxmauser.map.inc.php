<?php
$xpdo_meta_map['maxmaUser']= array (
  'package' => 'modmaxma',
  'version' => '1.1',
  'extends' => 'modUser',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
    'class_key' => 'maxmaUser',
  ),
  'fieldMeta' => 
  array (
    'class_key' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'null' => false,
      'default' => 'maxmaUser',
    ),
  ),
);
