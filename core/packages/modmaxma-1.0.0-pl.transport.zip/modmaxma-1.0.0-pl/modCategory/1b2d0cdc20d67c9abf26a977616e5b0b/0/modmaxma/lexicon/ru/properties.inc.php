<?php

$_lang['modmaxma_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['modmaxma_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['modmaxma_prop_sortby'] = 'Поле сортировки.';
$_lang['modmaxma_prop_sortdir'] = 'Направление сортировки.';
$_lang['modmaxma_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['modmaxma_prop_toPlaceholder'] = 'Если указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
