<?php

$_lang['area_modmaxma_main'] = 'Main';

$_lang['setting_modmaxma_some_setting'] = 'Some setting';
$_lang['setting_modmaxma_some_setting_desc'] = 'This is description for some setting';