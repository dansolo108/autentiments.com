<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for modMaxma.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '03bdcc0404a608f70225f890ac077393',
      'native_key' => 'modmaxma',
      'filename' => 'modNamespace/0ae94158f67c06a20c746b766a9949f3.vehicle',
      'namespace' => 'modmaxma',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd3fe4180177bcb96573aa1694adf9231',
      'native_key' => NULL,
      'filename' => 'modCategory/1b2d0cdc20d67c9abf26a977616e5b0b.vehicle',
      'namespace' => 'modmaxma',
    ),
  ),
);