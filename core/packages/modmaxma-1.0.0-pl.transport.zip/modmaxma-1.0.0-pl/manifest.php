<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for modMaxma.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9e581ecdbe1b21f2a3c3876c76a436de',
      'native_key' => 'modmaxma',
      'filename' => 'modNamespace/f3e8fc184792d1fa20d025ebafd0393f.vehicle',
      'namespace' => 'modmaxma',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '127e45c58f230864c207824a62b4217d',
      'native_key' => NULL,
      'filename' => 'modCategory/2f80c31b3ac2badb3058358b73406e55.vehicle',
      'namespace' => 'modmaxma',
    ),
  ),
);