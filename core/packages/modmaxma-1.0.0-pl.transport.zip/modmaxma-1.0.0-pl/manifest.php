<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for modMaxma.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b82b3dfe6a344ca4325a8101ec6b1dca',
      'native_key' => 'modmaxma',
      'filename' => 'modNamespace/0ec9daad0de6a1e54df89ccc25db6f33.vehicle',
      'namespace' => 'modmaxma',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e074ec57a5bbbb675ed7d6f155ccab2f',
      'native_key' => NULL,
      'filename' => 'modCategory/390f7c97d52cdc35705928a81837a3c9.vehicle',
      'namespace' => 'modmaxma',
    ),
  ),
);