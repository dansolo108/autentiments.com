<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for modMaxma.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1c373b8473bdb34bb9becd1ae3abb219',
      'native_key' => 'modmaxma',
      'filename' => 'modNamespace/d589b819dca888b4ee1e8f4ffa728cc1.vehicle',
      'namespace' => 'modmaxma',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '833a4c6e8360d93472316fd98418ae5c',
      'native_key' => NULL,
      'filename' => 'modCategory/583a10695f931e006cb02412c5bc1a05.vehicle',
      'namespace' => 'modmaxma',
    ),
  ),
);