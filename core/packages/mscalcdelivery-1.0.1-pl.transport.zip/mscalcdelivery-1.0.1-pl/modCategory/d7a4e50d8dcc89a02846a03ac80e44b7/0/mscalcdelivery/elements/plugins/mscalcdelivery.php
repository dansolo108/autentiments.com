<?php
/** @var modX $modx */
//$ns = $modx->getObject("modNamespace","mscalcdelivery");
//$fnotification = $modx->getService("msCalcDelivery","msCalcDelivery",$ns->get('path'));
