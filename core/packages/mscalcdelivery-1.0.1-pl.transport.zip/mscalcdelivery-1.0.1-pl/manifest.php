<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for msCalcDelivery.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '65ba267744198f4bf7f7b261b5a3febe',
      'native_key' => 'mscalcdelivery',
      'filename' => 'modNamespace/2f7042d8f8d817a8581ade40ccae8165.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56cc2cda67e515556c81eb250e812daa',
      'native_key' => 'mscalcdelivery_tpl',
      'filename' => 'modSystemSetting/2d774cfe599093e16f1a915c8e9dc8aa.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9373b86103dfbb6d2ec6c284ba53a58f',
      'native_key' => 'mscalcdelivery_emptyTpl',
      'filename' => 'modSystemSetting/2cd235bceadda6c11b975c23ce05329a.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'fff26a7814bb2c5a4df74019017741df',
      'native_key' => NULL,
      'filename' => 'modCategory/bb79985ba51bbc13899ce861819583e3.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
  ),
);