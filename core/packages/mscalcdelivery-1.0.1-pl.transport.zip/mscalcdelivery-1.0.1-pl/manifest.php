<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for msCalcDelivery.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '886e6af9b858f69af9763d199bf89558',
      'native_key' => 'mscalcdelivery',
      'filename' => 'modNamespace/6a0a3d3ce217c59e4a4d0653864dfcfe.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0301402a690f18903b2574a2fc681c66',
      'native_key' => 'mscalcdelivery_tpl',
      'filename' => 'modSystemSetting/45a8e19416268f96c7d3b742caf1e658.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bafbd7be6ba1579339e7bfd2ea0f3e1',
      'native_key' => 'mscalcdelivery_emptyTpl',
      'filename' => 'modSystemSetting/1d8288ec460e4dcbf42f1bd1f439c2f9.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '57845ecbd25464ab424d1c217d957fb0',
      'native_key' => NULL,
      'filename' => 'modCategory/7d596a214c9322e58acd5c3c9792edd4.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
  ),
);