<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for msCalcDelivery.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'dca3367cd3d87599fa74092f551f29a6',
      'native_key' => 'mscalcdelivery',
      'filename' => 'modNamespace/f4c7d46825ba6a33fd9f0e6ecc43e98a.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd853f0edfa6f704b44a129510383adba',
      'native_key' => 'mscalcdelivery_tpl',
      'filename' => 'modSystemSetting/af021cdb3dc3f91c9581150bcab0ab36.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a72df78ab4e5f45ff228a8b3dbc795f',
      'native_key' => 'mscalcdelivery_emptyTpl',
      'filename' => 'modSystemSetting/52dacaf5351743d4f2978f7712aee40d.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4bd2c0899040a0fed33ff33c6af4182d',
      'native_key' => NULL,
      'filename' => 'modCategory/bc1579dd149c533cf5d0e58c915158e6.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
  ),
);