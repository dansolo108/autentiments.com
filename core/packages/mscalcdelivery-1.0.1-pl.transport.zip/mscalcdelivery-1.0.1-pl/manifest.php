<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for msCalcDelivery.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '91b5dd42e0d8e00d594fe892fb5c3d7b',
      'native_key' => 'mscalcdelivery',
      'filename' => 'modNamespace/2c6d7021cf9fb0eb99fb8ce80cdfcc8b.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e0863fc8edacb102a00aebc13fdec9a',
      'native_key' => 'mscalcdelivery_tpl',
      'filename' => 'modSystemSetting/aad3a7b7c4e5c2af8a005dfccd312aa0.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ddfb3cc8a4b10ef4b7a2cc2e87395af',
      'native_key' => 'mscalcdelivery_emptyTpl',
      'filename' => 'modSystemSetting/013f8baf5500525d2e1c0c3a87426592.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7d31caf9a515bb92511cac3d2a1d891d',
      'native_key' => NULL,
      'filename' => 'modCategory/338c2a1601f07b5b4b5964edbec513a9.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
  ),
);