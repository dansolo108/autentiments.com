<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for msCalcDelivery.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a8da897892a3861ec5cf50ba6d78e1a7',
      'native_key' => 'mscalcdelivery',
      'filename' => 'modNamespace/59e338bc7ae7f89a3f8a1a2f3a01cacc.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f04f4b4c468d10e458e1b8ae9a57ed8',
      'native_key' => 'mscalcdelivery_tpl',
      'filename' => 'modSystemSetting/fdfaadb1d9a98e82375865904852c49e.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2d2b7d1f4d3b139aa1cdeb8a2b34f29',
      'native_key' => 'mscalcdelivery_emptyTpl',
      'filename' => 'modSystemSetting/ff9ca7adfcd964b47e029a1065b79490.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2c77ed65281b1eb35c3290393400a4ff',
      'native_key' => NULL,
      'filename' => 'modCategory/d7a4e50d8dcc89a02846a03ac80e44b7.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
  ),
);