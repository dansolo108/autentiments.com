<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for msCalcDelivery.

1.0.0
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions
',
    'license' => '
',
    'readme' => '
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '97b2abc9e226ef5ced5025c7935faae0',
      'native_key' => 'mscalcdelivery',
      'filename' => 'modNamespace/9d2cb3a0229514c38540024fa317756b.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da71b4fcf435e3c3083e768fc3de2448',
      'native_key' => 'mscalcdelivery_tpl',
      'filename' => 'modSystemSetting/4915f4a7afe9ea6358622744cda667c7.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c79e0043ef07d8252aca08179dddfb5',
      'native_key' => 'mscalcdelivery_emptyTpl',
      'filename' => 'modSystemSetting/c93385fd226cfd7bc29d13ff2ac92099.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '66b5927afa545dd3c5772094e4416fd5',
      'native_key' => NULL,
      'filename' => 'modCategory/5588f9d1f83902a4750f995ec72a0223.vehicle',
      'namespace' => 'mscalcdelivery',
    ),
  ),
);