<?php
/**
 * Russian permissions Lexicon Entries for amocrm
 *
 * @package amocrm
 * @subpackage lexicon
 */
$_lang['amocrm_save'] = 'Разрешает создание/изменение данных.';