<?php
require_once (dirname(__DIR__) . '/amocrmorderstatus.class.php');
class amoCRMOrderStatus_mysql extends amoCRMOrderStatus {}