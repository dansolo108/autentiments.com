<?php

class amoCRMOrderStatus extends xpdoSimpleObject
{
}
