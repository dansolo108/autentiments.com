<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'amoCRMUser',
    1 => 'amoCRMLead',
    2 => 'amoCRMOrderStatus',
    3 => 'amoCRMCustomField',
  ),
);