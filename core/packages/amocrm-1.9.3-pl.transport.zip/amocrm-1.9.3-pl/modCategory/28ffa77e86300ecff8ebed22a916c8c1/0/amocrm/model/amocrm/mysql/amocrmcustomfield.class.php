<?php
require_once (dirname(__DIR__) . '/amocrmcustomfield.class.php');
class amoCRMCustomField_mysql extends amoCRMCustomField {}