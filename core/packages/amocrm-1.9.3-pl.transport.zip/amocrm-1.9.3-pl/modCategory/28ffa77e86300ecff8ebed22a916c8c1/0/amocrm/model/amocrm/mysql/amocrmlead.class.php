<?php
require_once (dirname(__DIR__) . '/amocrmlead.class.php');
class amoCRMLead_mysql extends amoCRMLead {}