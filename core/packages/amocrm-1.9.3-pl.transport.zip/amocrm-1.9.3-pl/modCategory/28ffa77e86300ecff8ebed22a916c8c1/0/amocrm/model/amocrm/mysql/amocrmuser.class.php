<?php
require_once (dirname(__DIR__) . '/amocrmuser.class.php');
class amoCRMUser_mysql extends amoCRMUser {}