--------------------
amoCRM
--------------------
Author: Mikhail Voevodskiy
Support:  Nikolay Savin info@megawebs.kz
--------------------

Module integration between AmoCRM and Revolution.