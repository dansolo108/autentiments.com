<?php

class amoCRMLead extends xPDOSimpleObject
{
}
