<?php

class amoCRMCustomField extends xpdoSimpleObject
{
}
