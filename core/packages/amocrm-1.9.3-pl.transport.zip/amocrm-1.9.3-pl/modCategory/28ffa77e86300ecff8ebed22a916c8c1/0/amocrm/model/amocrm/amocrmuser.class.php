<?php

class amoCRMUser extends xPDOSimpleObject
{
}
